// pages/api/matches.js
// Chiamata server-side a football-data.org — nessun problema CORS

export default async function handler(req, res) {
  const { date } = req.query;

  if (!date) {
    return res.status(400).json({ error: "Missing date parameter" });
  }

  const API_KEY = process.env.FOOTBALL_API_KEY;

  try {
    // Prima prova: partite di Serie A per la data richiesta
    const response = await fetch(
      `https://api.football-data.org/v4/competitions/SA/matches?dateFrom=${date}&dateTo=${date}`,
      { headers: { "X-Auth-Token": API_KEY } }
    );

    if (!response.ok) {
      throw new Error(`Football API error: ${response.status}`);
    }

    const data = await response.json();
    const matches = data.matches || [];

    // Se non ci sono partite quel giorno, prendi le ultime 6 giocate
    if (matches.length === 0) {
      const fallbackRes = await fetch(
        `https://api.football-data.org/v4/competitions/SA/matches?status=FINISHED&limit=6`,
        { headers: { "X-Auth-Token": API_KEY } }
      );
      const fallbackData = await fallbackRes.json();
      const fallbackMatches = (fallbackData.matches || []).slice(-6);

      return res.status(200).json({
        matches: formatMatches(fallbackMatches),
        source: "fallback",
      });
    }

    return res.status(200).json({
      matches: formatMatches(matches),
      source: "live",
    });

  } catch (error) {
    console.error("Matches API error:", error);
    return res.status(500).json({ error: error.message });
  }
}

function formatMatches(raw) {
  return raw.map(m => ({
    id: m.id,
    home: m.homeTeam.shortName || m.homeTeam.name,
    homeTla: m.homeTeam.tla,
    away: m.awayTeam.shortName || m.awayTeam.name,
    awayTla: m.awayTeam.tla,
    date: m.utcDate.split("T")[0],
    utcDate: m.utcDate,
    stage: m.stage,
    status: m.status,
    scoreHome: m.score?.fullTime?.home ?? null,
    scoreAway: m.score?.fullTime?.away ?? null,
  }));
}
